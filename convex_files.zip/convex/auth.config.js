  export default {
    providers: [
    {
      "domain": "https://constituent-circle.vercel.app",
      "applicationID": "constituent-circle"
    }
  ],
  };