# Convex API Documentation

## Data Models

The following data models are available in the Convex database:

## Profiles

### Get profiles

```javascript
const profiles = useQuery(api.profiles.getAll);
```